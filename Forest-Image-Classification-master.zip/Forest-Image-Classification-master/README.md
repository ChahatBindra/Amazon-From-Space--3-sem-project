# Forest-Image-Classification

Our team got motivation to this project in response to recent fires in Amazon forest. We developed a classifier in which you can feed the images and it will classify them in 17 possible classes.

- Clone the repo
- Downlaod weights from: https://drive.google.com/open?id=1pzAHkA0aYLwdubiRO5yC9Og8kxucNlnZ
- Put those weights in notebooks/weights/weights.best.hdf5
- Run the flask application using python app.py in main directory
